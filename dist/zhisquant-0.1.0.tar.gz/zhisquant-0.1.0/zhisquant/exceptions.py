class APIError(Exception):
    """自定义API异常类，用于处理API请求错误"""
    pass
